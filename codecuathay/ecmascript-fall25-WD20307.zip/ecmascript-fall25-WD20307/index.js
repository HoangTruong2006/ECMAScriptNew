/*
 * Lesson1: https://github.com/vanhoa690/ecmascript-fall25/blob/main/note/lesson1.md
 * Lesson2: https://github.com/vanhoa690/ecmascript-fall25/blob/main/note/lesson2.md
 * Lesson3: https://github.com/vanhoa690/ecmascript-fall25/blob/main/note/lesson3.md
 */
