export const PI = 3.14
export function sum(a, b) {
  return a + b
}

export default function multiply(a, b) {
  return a * b
}
